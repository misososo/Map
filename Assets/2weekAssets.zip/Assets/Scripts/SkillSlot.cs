using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillSlot : MonoBehaviour
{
    GameObject[] slot = new GameObject[8];

    // Start is called before the first frame update
    void Start()
    {
        int childIndex = 0;

        for(int i = 0; i < transform.childCount; ++i)
        {
            slot[i] = transform.GetChild(childIndex).gameObject;
        }
      
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
